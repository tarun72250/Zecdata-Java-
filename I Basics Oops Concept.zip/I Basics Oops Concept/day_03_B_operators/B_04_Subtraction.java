package day_03_B_operators;

public class A_04_Subtraction {

public static void main(String[] args) {
		
		int a = 12;
		int b = 10;
		
		System.out.println((a-b));//2
		
		//or
		int result = a-b;//2
		System.out.println(result);
		
		
		//Unary Operation for multiplication
		int c = 15;
			c = c-2;//13
			System.out.println(c);

		//assignment operator
		int d = 20;
			d -=2;//40
			System.out.println(d);
		
	}
}
