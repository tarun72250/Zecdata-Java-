package day_03_B_operators;

public class A_03_Addition {

public static void main(String[] args) {
		
		int a = 12;
		int b = 10;
		
		System.out.println((a+b));//22
		
		//or
		int result = a+b;//22
		System.out.println(result);
		
		
		//Unary Operation for multiplication
		int c = 15;
			c = c+2;//17
			System.out.println(c);

		//assignment operator
		int d = 20;
			d +=2;//22
			System.out.println(d);
		
	}
	
}
