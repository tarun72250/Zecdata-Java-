package day_03_B_operators;

public class A_05_Division {


public static void main(String[] args) {
		
		int a = 12;
		int b = 10;
		
		System.out.println((a/b));//1
		
		//or
		int result = a/b;//1
		System.out.println(result);
		
		
		//Unary Operation for multiplication
		int c = 15;
			c = c/2;//7
			System.out.println(c);

		//assignment operator
		int d = 20;
			d /=2;//10
			System.out.println(d);
		
	}
}
