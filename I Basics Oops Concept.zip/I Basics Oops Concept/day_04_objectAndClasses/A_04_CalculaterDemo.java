package day_04_objectAndClasses;

public class A_04_CalculaterDemo {

	public static void main(String[] args) {
		
		A_04_Calculater c1 = new A_04_Calculater(10,5);
		c1.add();
		c1.sub();
		c1.mul();
		c1.div();
		
	}

}
