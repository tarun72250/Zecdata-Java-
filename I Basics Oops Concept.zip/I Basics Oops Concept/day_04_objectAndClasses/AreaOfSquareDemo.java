package day_04_objectAndClasses;

public class AreaOfSquareDemo {

	public static void main(String[] args) {


		ArarOfSquare a = new ArarOfSquare();
		a.display();
		
		ArarOfSquare a2 = new ArarOfSquare(4);
		a2.display();
		
		
		int[] numbers = {1, 2, 3, 4, 5};
		for (int number : numbers) {
		    System.out.println(number);
		}
	}

}

