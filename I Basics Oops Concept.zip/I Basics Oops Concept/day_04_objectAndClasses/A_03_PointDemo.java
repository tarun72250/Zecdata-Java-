package day_04_objectAndClasses;

public class A_03_PointDemo {

	public static void main(String[] args) {
		
		A_03_Point p = new A_03_Point();
		p.display(10,20);
		
		
	}

}
