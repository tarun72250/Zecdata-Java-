package day_04_objectAndClasses;

public class A_05_MathDemo {

	public static void main(String[] args) {

		A_05_Math m ;
		m = new A_05_Math();
		m.addition(2, 3, 4);
		

		A_05_Math m1 ;
		m1 = new A_05_Math();
		m1.addition(2, 3);
		

		A_05_Math m3 ;
		m3 = new A_05_Math();
		m3.addition(2.3f, 3.7f);
	}

}
