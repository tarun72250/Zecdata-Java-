package day_04_objectAndClasses;

public class A_05_Math {
		
	public void addition(int aa, int bb , int cc)
	{
		 int result = aa + bb + cc ;
		 System.out.println("Addition of 3 integer :"+ result );
	}
	
	public void addition(int aa, int bb )
	{
		 int result = aa + bb ;
		 System.out.println("Addition of 2 integer :"+ result );
	}
	
	public void addition(float aa, float bb )
	{
		 float result = aa + bb ;
		 System.out.println("Addition of 2 integer :"+ result );
	}
		
	
}
