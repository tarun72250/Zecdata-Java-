package day_03_D_jumpStatements;

public class BreakClass {

	public static void main(String[] args) {
		
		for(int i=0 ; i<=10 ; i++)
		{
			System.out.println(i);
			if(i==5)
			{
				break;
			}
		}
		

	}

}






















































/*
 for(int i = 0; i < 10; i++) //0<10 
	        {
	            // number is not more than 5
	        	 System.out.print(i + " "); //0
	        	if(i == 5)
	        	{
	        		break;
	        	}
	        }
*/