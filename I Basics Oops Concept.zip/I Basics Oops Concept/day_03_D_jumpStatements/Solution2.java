package day_03_D_jumpStatements;

public class Solution2 {

	public static void main(String[] args) {
		
		for(int i=0 ; i<5 ; i++)
		{
			if(i==3)
			{
				continue;
			}
			System.out.println(i+" ");
		}
	}

}
