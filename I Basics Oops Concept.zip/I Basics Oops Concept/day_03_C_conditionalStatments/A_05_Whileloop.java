package day_03_C_conditionalStatments;

public class A_05_Whileloop {
 
	public static void main(String[] args) {
		
		int num = 1;
		
		//Executes the code only if the condition is true from the start.

		while(num <=10)
		{
			System.out.println(5+ "*"+num+"="+ (5*num));
			num++;
		}
		
		
		
		
	}
}
