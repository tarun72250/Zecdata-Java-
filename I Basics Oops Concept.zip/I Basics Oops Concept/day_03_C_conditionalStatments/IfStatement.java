package day_03_C_conditionalStatments;

public class IfStatement {

	public static void main(String[] args) {
		
		
		int a =23;
		int b =33;
		
		if(a > b)
		{
			System.out.println("Value of a is :");
			System.out.println(a);
		}
		

	}

}
