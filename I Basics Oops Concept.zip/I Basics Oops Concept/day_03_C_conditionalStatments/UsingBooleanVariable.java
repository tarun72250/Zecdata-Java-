package day_03_C_conditionalStatments;

public class UsingBooleanVariable {

	public static void main(String[] args) {
		
		int x = 100;
		int y = 93;
		System.out.println(x > y); // returns true, because 100 is higher than 93

		
		boolean isJavaFun = true;
		boolean isFishTasty = false;
		System.out.println("Variable name (isJavaFun) ="+isJavaFun);     // Outputs true
		System.out.println("Variable name (isFishTasty)="+isFishTasty);   // Outputs false

		int z = 10;
		System.out.println(z == 10);
		System.out.println("Z is equal");// returns true, because the value of x is equal to 10

	}

}
