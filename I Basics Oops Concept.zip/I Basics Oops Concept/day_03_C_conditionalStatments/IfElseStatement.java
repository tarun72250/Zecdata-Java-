package day_03_C_conditionalStatments;

public class IfElseStatement {

	public static void main(String[] args) {
	
		int a =42;
		int b =8;
		
		if(b > a)
		{
			System.out.println("a is bigger :- "+a);
		}
		else
		{
			System.out.println("b is bigger :- "+b);
		}

	}

}
