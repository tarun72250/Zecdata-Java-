package day_03_C_conditionalStatments;

public class TernaryClassOperator {

	public static void main(String[] args) {

		int a = 120;
		String result = (a < 118) ? "Good day." : "Good evening.";
		System.out.println(result);
		
		
		int b = 14;
		int z = (b < 12) ? 2 : 3;
		System.out.println(z);
		

	}

}
