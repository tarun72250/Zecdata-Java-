package day_03_C_conditionalStatments;

public class A_05_ForLoop {

	public static void main(String[] args) {

//		for(char i='a' ; i<='z' ; i++)
//		{
//			System.out.println(i);
//		}
		
		char num ='A';
		
		while(num <='Z')
		{
			System.out.println(num);//
			num++;
		}
	}

}
