package day_03_C_conditionalStatments;

public class A_05_DoWhileLoop {
	
	
	public static void main(String[] args) {
		

		//Executes the code at least once, then checks the condition.
		int i = 1;
		 
		do 
		{
			System.out.println(3+" * "+i+" = "+(3*i));
			i++; 
		}
		while(i<=10);
	}
	

}
