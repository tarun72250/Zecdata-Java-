package day_03_C_conditionalStatments;

public class A_02_IfElseStatement {

	public static void main(String[] args) {
	
		int a = 100;
		int b = 200;
		
		if(a>b)
		{
			System.out.println("a is bigger ");
		}
		else
		{
			System.out.println("b is bigger");
		}
		
		
		
		
		
		String str = "Sourabh";
		String str1 ="Sourabh";
		
		if(str==str1)
		{
			System.out.println("Same");
		}
		else
		{
			System.out.println("Different");
		}
		

	}

}
