package day_03_E_iterativeStatements;

public class ScopeOfVariable {

	
	int sumit ;//instance variable//instance data members / state of class
	String sourabh ;//instance variable /non-static variable//
	
	static int suraj;//static integer variable/static means common for all type of ScopeOfVariable
	
	
	public ScopeOfVariable(int value)//local variable of this method)
	{
		sumit=value;
	}
	
	public static void main(String[] args) {
		
		System.out.println();
	}
}
