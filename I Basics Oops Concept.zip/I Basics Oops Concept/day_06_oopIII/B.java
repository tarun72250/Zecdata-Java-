package day_06_oopIII;

public class B extends A{
	 
	
//	 public void tarun()
//	 {
//		 
//	 }
//	 public static void main(String[] args) {
//		
//		 B b = new B();
//		 b.sumit();
//	}
}
