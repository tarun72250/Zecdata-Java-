package day_06_oopIII;

public class FinaleKeywordUseClass {

	public static void main(String[] args) {
		   
		 //final keyword
		    final int var =80;
		    	//	var =90;//this get error bcoz final value once initialized can't changed 
			//we cannot re assigned final variable.
		  
		   
		 
		
	}
	//finalize() this method is called just before the object is garbage collected, 
    protected void finalize()
    {
    	
    }

}
