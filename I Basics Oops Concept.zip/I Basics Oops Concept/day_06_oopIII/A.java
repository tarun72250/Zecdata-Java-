package day_06_oopIII;

 public class A {

	public final void tarun()
	{
		System.out.println("Tarun");
	}
}
 