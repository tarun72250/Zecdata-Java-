package day_06_oopIII;

public class Date2ClassDemo {

	public static void main(String[] args) {
		
		Date2Class d1=new Date2Class(12,12,2022);
		d1.ShowDate();
		
		Date2Class d2=new Date2Class();
		d2.ShowDate();
		
		Date2Class d3=new Date2Class(13,05,2000);
		d3.ShowDate();
		
		Date2Class d4=new Date2Class(19,04,2023);
		d4.ShowDate();

	}

}
