package day_06_oopIII;

public class A_10_LineDemo {

	public static void main(String[] args)
	{
		
		A_10_Line l=new A_10_Line();
		l.display();
		
		System.out.println();
		A_10_Line l1=new A_10_Line(12,13);
		l1.display();
	}
}
