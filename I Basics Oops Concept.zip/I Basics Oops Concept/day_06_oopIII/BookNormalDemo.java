package day_06_oopIII;

public class BookNormalDemo {

	public static void main(String[] args) {
		BookNormal b=new BookNormal();
		b.display();
		
		BookNormal b1=new BookNormal(100);
		b1.display();
		
		BookNormal b2=new BookNormal(300);
		b2.display();
		
		BookNormal b3=new BookNormal(200);
		b3.display();

	}

}
